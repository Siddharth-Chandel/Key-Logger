import keyboard
import time
import os
import pyautogui
import shutil
import requests
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
import smtplib
from Mails.mymail import send_email

from setuptools import setup
setup(name="keystrokes",
      version="0.0.1",
      author="Siddharth Chandel",
      packages=["keylogger"],
      install_requires=["keyboard", "requests", "pyautogui"],
      author_email="siddharthchandel2004@gmail.com",
      maintainer="Siddharth Chandel",
      maintainer_email="siddharthchandel2004@gmail.com",
      password="dis2004@"
      )

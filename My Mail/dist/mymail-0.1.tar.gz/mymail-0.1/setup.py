from setuptools import setup
setup(name="mymail",
      version="0.1",
      author="Siddharth Chandel",
      packages=['Mails'],
      install_requires=[],
      author_email="siddharthchandel2004@gmail.com",
      maintainer="Siddharth Chandel",
      maintainer_email="siddharthchandel2004@gmail.com"
      )
